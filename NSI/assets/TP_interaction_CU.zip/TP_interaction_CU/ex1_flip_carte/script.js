let image = null; // remplacer null par un sélecteur pour l'élément image de
// la page.
let visible = false;

function retourne() {
    if (!visible) {


    } else {


    }
}

// Attacher la fonction retourne à image
