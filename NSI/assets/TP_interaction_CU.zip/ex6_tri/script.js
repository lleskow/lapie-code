function echange(tab, i, j) {

}

// A décommenter pour tester echange
// let test_tab = [5, 1, 7];
// test_tab = echange(test_tab, 0, 2);
// alert(test_tab);


function melange(tab) {

}

// A décommenter pour tester melange
// let test_melange = [5, 1, 7, 8, 9];
// test_melange = melange(test_melange);
// alert(test_melange);
